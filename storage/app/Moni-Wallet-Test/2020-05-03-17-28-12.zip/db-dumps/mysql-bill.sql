
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `summary` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES (1,3,1,'Transfer of 100 from user','2020-05-01 13:51:45','2020-05-01 13:51:45'),(2,2,1,'Transfer of 100 to individual','2020-05-01 13:51:54','2020-05-01 13:51:54'),(3,4,4,'Account created','2020-05-01 14:39:25','2020-05-01 14:39:25'),(4,1,1,'Profile was edited','2020-05-01 18:02:27','2020-05-01 18:02:27'),(5,1,1,'Profile was edited','2020-05-01 18:02:57','2020-05-01 18:02:57'),(6,1,1,'Profile was edited','2020-05-01 18:04:54','2020-05-01 18:04:54'),(7,1,1,'Profile was edited','2020-05-01 18:05:08','2020-05-01 18:05:08'),(8,1,1,'Profile was edited','2020-05-01 18:05:13','2020-05-01 18:05:13'),(9,1,1,'Profile was edited','2020-05-01 18:07:43','2020-05-01 18:07:43'),(10,1,1,'Profile was edited','2020-05-01 18:08:10','2020-05-01 18:08:10'),(11,1,1,'Profile was edited','2020-05-01 18:08:17','2020-05-01 18:08:17'),(12,5,5,'Wallet funding of 200 from online payment','2020-05-02 15:47:15','2020-05-02 15:47:15'),(13,5,5,'Wallet funding of 200 from online payment','2020-05-02 15:49:45','2020-05-02 15:49:45'),(14,5,5,'Wallet funding of 200 from online payment','2020-05-02 15:50:26','2020-05-02 15:50:26'),(15,5,5,'Wallet funding of 200 from online payment','2020-05-02 15:52:01','2020-05-02 15:52:01'),(16,5,1,'Charges for previous transaction(s)','2020-05-02 21:07:40','2020-05-02 21:07:40'),(17,5,1,'Wallet funding of 1000 by admin','2020-05-03 08:59:56','2020-05-03 08:59:56'),(18,5,1,'Wallet funding of 1000 by admin','2020-05-03 09:03:32','2020-05-03 09:03:32');
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `guest_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guest_transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `amount` decimal(13,2) NOT NULL,
  `ref` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `guest_transactions` WRITE;
/*!40000 ALTER TABLE `guest_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `guest_transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2020_04_10_142952_create_transactions_table',1),(5,'2020_04_10_144151_create_activities_table',1),(6,'2020_04_10_155217_add_referral_to_users_table',1),(7,'2020_04_10_155217_create_referral_lists_table',1),(8,'2020_04_11_012502_create_subscriptions_table',1),(9,'2020_04_12_233702_create_referrals_table',1),(10,'2020_04_21_212036_create_guest_transactions_table',1),(11,'2020_05_03_114751_create_jobs_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `referral_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referral_lists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `ref_id` bigint(20) NOT NULL,
  `level` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `referral_lists_user_id_index` (`user_id`),
  KEY `referral_lists_ref_id_index` (`ref_id`),
  KEY `referral_lists_level_index` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `referral_lists` WRITE;
/*!40000 ALTER TABLE `referral_lists` DISABLE KEYS */;
INSERT INTO `referral_lists` VALUES (1,2,5,1,'2020-05-02 16:50:27','2020-05-02 16:50:27');
/*!40000 ALTER TABLE `referral_lists` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `referrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referrals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referral_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(13,2) NOT NULL,
  `balance` decimal(13,2) NOT NULL,
  `level` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ref` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `referrals_ref_unique` (`ref`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `referrals` WRITE;
/*!40000 ALTER TABLE `referrals` DISABLE KEYS */;
INSERT INTO `referrals` VALUES (1,'2020-05-02 15:50:27','2020-05-02 15:50:27','2','5',100.00,100.00,'1','Referral bonus for first time top-up','OeJ4ev12SQQm8J7k');
/*!40000 ALTER TABLE `referrals` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `amount` decimal(13,2) NOT NULL,
  `bonus` decimal(13,2) NOT NULL,
  `user_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_sub` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES (1,5000.00,1200.00,'2','basic',NULL,'1','2020-05-01 13:44:10','2020-05-01 13:44:10');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `amount` decimal(13,2) NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'debit',
  `user_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'top-up',
  `is_online` tinyint(1) NOT NULL DEFAULT '1',
  `ref` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `balance` decimal(13,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transactions_ref_unique` (`ref`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,1200.00,'credit','2','Subscription basic bonus','top-up',1,'8MtN1ve2J6XUIwk9',1200.00,'2020-05-01 13:44:10','2020-05-01 13:44:10'),(2,100.00,'credit','3','Transfer of 100 from user','top-up',1,'QYSx9M33Cm5wpWq7',100.00,'2020-05-01 13:51:45','2020-05-01 13:51:45'),(3,100.00,'debit','2','Transfer of 100 to individual','top-up',1,'HZHYIHQ21gLoDpQX',1100.00,'2020-05-01 13:51:54','2020-05-01 13:51:54'),(4,100.00,'debit',NULL,'Recharge of MTN ₦100.00 to 08106813749','airtime',1,'T108074611720336',0.00,'2020-05-02 03:17:12','2020-05-02 03:17:12'),(6,100.00,'debit','2','test','airtime',1,'12345',1200.00,'2020-05-02 14:25:10','2020-05-02 14:25:10'),(9,98.00,'debit','2','test','airtime',1,'12345678',1200.00,'2020-05-02 14:40:10','2020-05-02 14:40:10'),(12,200.00,'credit','5','Wallet funding of 200 from online payment','top-up',1,'T975395338475373',600.00,'2020-05-02 15:50:25','2020-05-02 15:50:25'),(13,200.00,'credit','5','Wallet funding of 200 from online payment','top-up',1,'T601584762069804',800.00,'2020-05-02 15:52:01','2020-05-02 15:52:01'),(14,100.00,'debit','5','Charges for previous transaction(s)','debit',1,'XJNMXoN52kvASE9s',700.00,'2020-05-02 21:07:40','2020-05-02 21:07:40'),(15,1000.00,'credit','5','Wallet funding of 1000 by admin','top-up',0,'ljDca5h5eYo9JaCO',1700.00,'2020-05-03 08:59:56','2020-05-03 08:59:56'),(16,1000.00,'credit','5','Wallet funding of 1000 by admin','top-up',0,'K13idKH5e57AvCIW',2700.00,'2020-05-03 09:03:32','2020-05-03 09:03:32');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `is_reseller` tinyint(1) NOT NULL DEFAULT '0',
  `balance` decimal(8,2) NOT NULL DEFAULT '0.00',
  `referral_balance` decimal(8,2) NOT NULL DEFAULT '0.00',
  `profile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ref_id` int(11) DEFAULT NULL,
  `points` bigint(20) NOT NULL DEFAULT '0',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `api_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate_limit` int(11) NOT NULL DEFAULT '60',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_login_unique` (`login`),
  KEY `users_ref_id_index` (`ref_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Abu','Lawwy','admin','08106813749',1,1,0,0.00,0.00,NULL,'apon?@gmail.com',NULL,0,NULL,'$2y$10$xvys04Shs.9MbuVEc3Wo0.bzpmCrNhUBO3NsWc6oXw/NJqMNuf2vu',NULL,60,'0Xm0gZFXCLA9PoGcSwXTQDcyiSFiMg0Lbe8HR0xaaWzRDSTmcuQHmJb0TE5H','2020-05-01 13:44:10','2020-05-01 18:08:17'),(2,'Tester','User','user',NULL,1,0,1,1100.00,100.00,NULL,'abula3003@gmail.com',NULL,100,NULL,'$2y$10$AfnYmW5iVAPQ7lFIQbduneJ8F.sZiLGZzYbdytmYDSok5brtRexna','abcde12345',60,NULL,'2020-05-01 13:44:10','2020-05-02 15:50:27'),(3,'Abubakar','Lawal','individual',NULL,1,0,0,100.00,0.00,NULL,'naijafixer112@gmail.com',NULL,0,NULL,'$2y$10$/DWFaxI/GJCC09VeB2j79uQnGHjg8PiRM./HoG0bHirhdWGrCspse','l8jPx6Pu8bmSRuiA8yNaKoCCS0S4ATkVR4F96rYQWtvuk6Gqt3K8kfAvwEPy',60,NULL,'2020-05-01 13:44:10','2020-05-01 13:51:45'),(4,'Abubakar','Lawal','tester','11111111111',1,0,1,0.00,0.00,NULL,'abc@gmail.com',NULL,0,NULL,'$2y$10$v9pMjgG3diyUrSTzss797uI.ef2avV4PD5FzwODaGtwpTL6GL6.IK','xYojIou7qh4MwSuRKKegCGSfM3l03nlkRSi51wdoScGV2mNh04qEqwAqhM8E',60,NULL,'2020-05-01 14:39:25','2020-05-01 14:39:25'),(5,'abu','Lomo','abula112','00000000000',1,0,0,2700.00,0.00,NULL,'test@gmail.com',2,0,NULL,'$2y$10$W/lTMmiTOy4nUiQz/vV2/.5ZVOhOY6A1aVM4QrgDQPL2wr9NImYH2','MLNq5J19n2n1m9amOTGBiCbJbHQq4LUFa9dFuG4w9N1s0lv3fSFxHUVjdcgy',60,NULL,'2020-05-02 15:44:35','2020-05-03 09:03:32');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

